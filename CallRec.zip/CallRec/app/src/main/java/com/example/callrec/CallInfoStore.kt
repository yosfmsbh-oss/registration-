package com.example.callrec

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.provider.CallLog
import java.io.File
import java.text.SimpleDateFormat
import java.util.Locale

object CallInfoStore {
    private fun side(f: File) = File(f.path + ".info")

    fun startOf(f: File): Long? = try {
        SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).parse(f.name.substring(4, 19))!!.time
    } catch (e: Exception) { null }

    fun load(f: File): CallInfo? = try {
        val p = side(f).readText().split("\n")
        if (p.size >= 3) CallInfo(p[0], p[1], p[2]) else null
    } catch (e: Exception) { null }

    private fun store(f: File, i: CallInfo) {
        try { side(f).writeText(i.name + "\n" + i.number + "\n" + i.dir) } catch (_: Exception) {}
    }

    fun query(ctx: Context, start: Long, end: Long): CallInfo? {
        if (ctx.checkSelfPermission(Manifest.permission.READ_CALL_LOG) != PackageManager.PERMISSION_GRANTED) return null
        try {
            ctx.contentResolver.query(
                CallLog.Calls.CONTENT_URI,
                arrayOf(CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME, CallLog.Calls.TYPE, CallLog.Calls.DATE, CallLog.Calls.DURATION),
                null, null, CallLog.Calls.DATE + " DESC"
            )?.use { c ->
                var n = 0
                while (c.moveToNext() && n < 40) {
                    n++
                    val date = c.getLong(3)
                    val dur = c.getLong(4)
                    if (date < start - 3600000L) break
                    if (date <= end + 5000 && date + dur * 1000 + 120000 >= start) {
                        val dir = when (c.getInt(2)) {
                            CallLog.Calls.INCOMING_TYPE -> "واردة"
                            CallLog.Calls.OUTGOING_TYPE -> "صادرة"
                            else -> ""
                        }
                        return CallInfo(c.getString(1) ?: "", c.getString(0) ?: "", dir)
                    }
                }
            }
        } catch (_: Exception) {}
        return null
    }

    fun get(ctx: Context, f: File): CallInfo? {
        load(f)?.let { return it }
        val start = startOf(f) ?: return null
        val i = query(ctx, start, f.lastModified()) ?: return null
        store(f, i)
        return i
    }

    fun saveAfterCall(ctx: Context, f: File) {
        val start = startOf(f) ?: return
        val i = query(ctx, start, System.currentTimeMillis()) ?: return
        store(f, i)
    }
}
