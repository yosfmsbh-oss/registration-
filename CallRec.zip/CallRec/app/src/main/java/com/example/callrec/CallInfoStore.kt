package com.example.callrec

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.provider.CallLog
import java.io.File
import java.text.SimpleDateFormat
import java.util.Collections
import java.util.Locale

object CallInfoStore {
    private const val SLACK_MS = 60_000L          // covers ringing time before answer
    private const val RETRY_WINDOW_MS = 300_000L  // keep retrying unmatched files for 5 min
    private val misses: MutableSet<String> = Collections.synchronizedSet(HashSet())

    private fun side(f: File) = File(f.path + ".info")
    private fun oneLine(s: String) = s.replace('\n', ' ').replace('\r', ' ')

    fun startOf(f: File): Long? = try {
        SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).parse(f.name.substring(4, 19))!!.time
    } catch (e: Exception) { null }

    fun load(f: File): CallInfo? = try {
        val p = side(f).readText().split("\n")
        if (p.size >= 3) CallInfo(p[0], p[1], p[2]) else null
    } catch (e: Exception) { null }

    private fun store(f: File, i: CallInfo) {
        try { side(f).writeText(oneLine(i.name) + "\n" + oneLine(i.number) + "\n" + oneLine(i.dir)) } catch (_: Exception) {}
    }

    fun query(ctx: Context, start: Long, end: Long): CallInfo? {
        if (ctx.checkSelfPermission(Manifest.permission.READ_CALL_LOG) != PackageManager.PERMISSION_GRANTED) return null
        try {
            ctx.contentResolver.query(
                CallLog.Calls.CONTENT_URI,
                arrayOf(CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME, CallLog.Calls.TYPE, CallLog.Calls.DATE, CallLog.Calls.DURATION),
                null, null, CallLog.Calls.DATE + " DESC"
            )?.use { c ->
                var n = 0
                while (c.moveToNext() && n < 40) {
                    n++
                    val date = c.getLong(3)
                    val dur = c.getLong(4)
                    if (date < start - 3600000L) break
                    if (date <= end + 5000 && date + dur * 1000 + SLACK_MS >= start) {
                        val dir = when (c.getInt(2)) {
                            CallLog.Calls.INCOMING_TYPE -> "واردة"
                            CallLog.Calls.OUTGOING_TYPE -> "صادرة"
                            else -> ""
                        }
                        return CallInfo(c.getString(1) ?: "", c.getString(0) ?: "", dir)
                    }
                }
            }
        } catch (_: Exception) {}
        return null
    }

    fun get(ctx: Context, f: File): CallInfo? {
        load(f)?.let { return it }
        // don't hammer the call log for files that never matched (voice memos etc.)
        if (f.name in misses && System.currentTimeMillis() - f.lastModified() > RETRY_WINDOW_MS) return null
        val start = startOf(f) ?: return null
        val i = query(ctx, start, f.lastModified())
        if (i == null) { misses.add(f.name); return null }
        misses.remove(f.name)
        store(f, i)
        return i
    }

    fun saveAfterCall(ctx: Context, f: File) {
        if (!f.exists()) return
        val start = startOf(f) ?: return
        val i = query(ctx, start, System.currentTimeMillis()) ?: return
        store(f, i)
    }
}
