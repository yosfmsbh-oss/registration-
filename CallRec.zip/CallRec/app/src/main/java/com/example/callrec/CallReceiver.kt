package com.example.callrec

import android.app.*
import android.content.*
import android.telephony.TelephonyManager

class CallReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action != TelephonyManager.ACTION_PHONE_STATE_CHANGED) return
        val nm = c.getSystemService(NotificationManager::class.java)
        when (i.getStringExtra(TelephonyManager.EXTRA_STATE)) {
            TelephonyManager.EXTRA_STATE_OFFHOOK -> {
                nm.createNotificationChannel(NotificationChannel("call", "المكالمات", NotificationManager.IMPORTANCE_HIGH))
                val start = PendingIntent.getForegroundService(
                    c, 2, RecorderService.intent(c, RecorderService.START), PendingIntent.FLAG_IMMUTABLE
                )
                nm.notify(2, Notification.Builder(c, "call")
                    .setContentTitle("مكالمة جارية")
                    .setContentText("شغّل مكبّر الصوت ثم اضغط بدء التسجيل")
                    .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                    .addAction(Notification.Action.Builder(null, "بدء التسجيل", start).build())
                    .build())
            }
            TelephonyManager.EXTRA_STATE_IDLE -> {
                nm.cancel(2)
                if (RecorderService.recording.value) {
                    try { c.startService(RecorderService.intent(c, RecorderService.STOP)) } catch (_: Exception) {}
                }
            }
        }
    }
}
