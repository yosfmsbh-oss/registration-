package com.example.callrec

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.MediaRecorder
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.compose.runtime.mutableStateOf
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class RecorderService : Service() {
    companion object {
        const val START = "start"
        const val STOP = "stop"
        private const val EXTRA_AUTO = "auto"
        private const val TAG = "CallRec"
        val recording = mutableStateOf(false)
        @Volatile var lastFile: File? = null
        /** true when the current recording was started automatically by a call */
        @Volatile var auto = false
        @Volatile var instance: RecorderService? = null
        fun dir(c: Context) = File(c.getExternalFilesDir(null), "Recordings").apply { mkdirs() }
        fun intent(c: Context, a: String, auto: Boolean = false): Intent =
            Intent(c, RecorderService::class.java).setAction(a).putExtra(EXTRA_AUTO, auto)
    }

    private var rec: MediaRecorder? = null
    private var curFile: File? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() { super.onCreate(); instance = this }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        when (i?.action) {
            STOP -> stopNow()
            START -> startRec(i.getBooleanExtra(EXTRA_AUTO, false))
            else -> stopSelf()
        }
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun newRecorder(): MediaRecorder =
        if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()

    private fun startRec(isAuto: Boolean) {
        if (rec != null) return
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("rec2", "التسجيل", NotificationManager.IMPORTANCE_MIN))
        val stop = PendingIntent.getService(this, 0, intent(this, STOP), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "rec2")
            .setContentTitle("جارٍ التسجيل")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_media_pause), "إيقاف", stop
                ).build()
            )
            .build()
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            else startForeground(1, n)
        } catch (e: Exception) {
            Log.e(TAG, "startForeground failed", e)
            stopSelf(); return
        }
        val name = "rec_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".m4a"
        val outFile = File(dir(this), name)
        try {
            rec = newRecorder().apply {
                setAudioSource(MediaRecorder.AudioSource.VOICE_RECOGNITION)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setAudioEncodingBitRate(96000)
                setOutputFile(outFile.path)
                prepare(); start()
            }
            curFile = outFile
            lastFile = outFile
            auto = isAuto
            recording.value = true
        } catch (e: Exception) {
            Log.e(TAG, "recorder start failed", e)
            try { rec?.release() } catch (_: Exception) {}
            rec = null
            outFile.delete()
            File(outFile.path + ".info").delete()
            recording.value = false
            stopSelf()
        }
    }

    /** Stops the recording and the service. Safe to call from other components (main thread). */
    fun stopNow() { stopRec(); stopSelf() }

    private fun stopRec() {
        val r = rec
        val f = curFile
        rec = null; curFile = null
        if (r != null) {
            var ok = true
            try { r.stop() } catch (e: Exception) { ok = false; Log.e(TAG, "recorder stop failed", e) }
            try { r.release() } catch (_: Exception) {}
            if (!ok) { f?.delete(); f?.let { File(it.path + ".info").delete() } }
        }
        recording.value = false
        auto = false
        try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (_: Exception) {}
    }

    override fun onDestroy() {
        stopRec()
        if (instance === this) instance = null
        super.onDestroy()
    }
}
