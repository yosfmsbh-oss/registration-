package com.example.callrec

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.MediaRecorder
import android.os.IBinder
import androidx.compose.runtime.mutableStateOf
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class RecorderService : Service() {
    companion object {
        const val START = "start"
        const val STOP = "stop"
        val recording = mutableStateOf(false)
        fun dir(c: Context) = File(c.getExternalFilesDir(null), "Recordings").apply { mkdirs() }
        fun intent(c: Context, a: String) = Intent(c, RecorderService::class.java).setAction(a)
    }

    private var rec: MediaRecorder? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.action == STOP) { stopRec(); stopSelf() } else startRec()
        return START_NOT_STICKY
    }

    private fun startRec() {
        if (rec != null) return
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("rec", "التسجيل", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 0, intent(this, STOP), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "rec")
            .setContentTitle("جارٍ التسجيل")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .addAction(Notification.Action.Builder(null, "إيقاف", stop).build())
            .build()
        try {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } catch (e: Exception) { stopSelf(); return }
        nm.cancel(2)
        val name = "rec_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".m4a"
        try {
            rec = MediaRecorder(this).apply {
                setAudioSource(MediaRecorder.AudioSource.VOICE_RECOGNITION)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setAudioEncodingBitRate(96000)
                setOutputFile(File(dir(this@RecorderService), name).path)
                prepare(); start()
            }
            recording.value = true
        } catch (e: Exception) {
            rec?.release(); rec = null; stopSelf()
        }
    }

    private fun stopRec() {
        try { rec?.stop() } catch (_: Exception) {}
        rec?.release(); rec = null
        recording.value = false
        stopForeground(STOP_FOREGROUND_REMOVE)
    }

    override fun onDestroy() { stopRec(); super.onDestroy() }
}
