package com.example.callrec

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.telephony.PhoneStateListener
import android.telephony.TelephonyCallback
import android.telephony.TelephonyManager
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import androidx.core.content.ContextCompat

class CallAccessibilityService : AccessibilityService() {
    private var legacy: PhoneStateListener? = null
    private var modern: Any? = null
    private var registered = false
    private val handler = Handler(Looper.getMainLooper())

    // Retries until READ_PHONE_STATE is granted, so the order of enabling the
    // service / granting permissions does not matter.
    private val retry = object : Runnable {
        override fun run() {
            register()
            if (!registered) handler.postDelayed(this, 4000)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        handler.removeCallbacks(retry)
        handler.post(retry)
    }

    private fun register() {
        if (registered) return
        if (checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) return
        val tm = getSystemService(TelephonyManager::class.java) ?: return
        try {
            if (Build.VERSION.SDK_INT >= 31) {
                val cb = object : TelephonyCallback(), TelephonyCallback.CallStateListener {
                    override fun onCallStateChanged(state: Int) = handle(state)
                }
                tm.registerTelephonyCallback(ContextCompat.getMainExecutor(this), cb)
                modern = cb
            } else {
                @Suppress("DEPRECATION")
                val l = object : PhoneStateListener() {
                    @Deprecated("old API")
                    override fun onCallStateChanged(state: Int, number: String?) = handle(state)
                }
                @Suppress("DEPRECATION")
                tm.listen(l, PhoneStateListener.LISTEN_CALL_STATE)
                legacy = l
            }
            registered = true
        } catch (e: Exception) {
            Log.e("CallRec", "register call listener failed", e)
        }
    }

    private fun handle(state: Int) {
        when (state) {
            TelephonyManager.CALL_STATE_OFFHOOK -> {
                if (RecorderService.recording.value) return
                try {
                    startForegroundService(RecorderService.intent(this, RecorderService.START, auto = true))
                } catch (e: Exception) {
                    Log.e("CallRec", "cannot start recording service", e)
                }
            }
            TelephonyManager.CALL_STATE_IDLE ->
                // only stop recordings that a call started; never a manual one
                if (RecorderService.recording.value && RecorderService.auto) {
                    val f = RecorderService.lastFile
                    val svc = RecorderService.instance
                    try {
                        if (svc != null) svc.stopNow()
                        else startService(RecorderService.intent(this, RecorderService.STOP))
                    } catch (e: Exception) {
                        Log.e("CallRec", "cannot stop recording", e)
                    }
                    if (f != null) handler.postDelayed({
                        Thread { CallInfoStore.saveAfterCall(applicationContext, f) }.start()
                    }, 3000)
                }
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        if (registered) {
            try {
                val tm = getSystemService(TelephonyManager::class.java)
                if (Build.VERSION.SDK_INT >= 31) (modern as? TelephonyCallback)?.let { tm.unregisterTelephonyCallback(it) }
                else @Suppress("DEPRECATION") legacy?.let { tm.listen(it, PhoneStateListener.LISTEN_NONE) }
            } catch (e: Exception) { Log.e("CallRec", "unregister failed", e) }
            registered = false
        }
        super.onDestroy()
    }
}
