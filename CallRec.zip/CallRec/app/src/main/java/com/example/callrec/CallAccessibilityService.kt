package com.example.callrec

import android.accessibilityservice.AccessibilityService
import android.os.Build
import android.telephony.PhoneStateListener
import android.telephony.TelephonyCallback
import android.telephony.TelephonyManager
import android.view.accessibility.AccessibilityEvent
import androidx.core.content.ContextCompat

class CallAccessibilityService : AccessibilityService() {
    private var legacy: PhoneStateListener? = null
    private var modern: Any? = null

    override fun onServiceConnected() {
        val tm = getSystemService(TelephonyManager::class.java)
        try {
            if (Build.VERSION.SDK_INT >= 31) {
                val cb = object : TelephonyCallback(), TelephonyCallback.CallStateListener {
                    override fun onCallStateChanged(state: Int) = handle(state)
                }
                modern = cb
                tm.registerTelephonyCallback(ContextCompat.getMainExecutor(this), cb)
            } else {
                @Suppress("DEPRECATION")
                val l = object : PhoneStateListener() {
                    @Deprecated("old API")
                    override fun onCallStateChanged(state: Int, number: String?) = handle(state)
                }
                legacy = l
                @Suppress("DEPRECATION")
                tm.listen(l, PhoneStateListener.LISTEN_CALL_STATE)
            }
        } catch (_: SecurityException) {
            // READ_PHONE_STATE not granted yet
        }
    }

    private fun handle(state: Int) {
        when (state) {
            TelephonyManager.CALL_STATE_OFFHOOK -> try {
                startForegroundService(RecorderService.intent(this, RecorderService.START))
            } catch (_: Exception) { /* the call notification (CallReceiver) stays as fallback */ }
            TelephonyManager.CALL_STATE_IDLE ->
                if (RecorderService.recording.value) {
                    try { startService(RecorderService.intent(this, RecorderService.STOP)) } catch (_: Exception) {}
                }
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        val tm = getSystemService(TelephonyManager::class.java)
        if (Build.VERSION.SDK_INT >= 31) (modern as? TelephonyCallback)?.let { tm.unregisterTelephonyCallback(it) }
        else @Suppress("DEPRECATION") legacy?.let { tm.listen(it, PhoneStateListener.LISTEN_NONE) }
        super.onDestroy()
    }
}
