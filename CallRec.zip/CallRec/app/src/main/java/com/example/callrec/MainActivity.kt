package com.example.callrec

import android.Manifest
import android.content.Context
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.os.Build
import android.os.Bundle
import android.provider.CallLog
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.res.painterResource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

private val Teal = Color(0xFF0E7C86)
private val Ink = Color(0xFF1C1917)
private val Muted = Color(0xFF78716C)
private val Line = Color(0xFFEFEDEB)
private val Bg = Color(0xFFFAFAF9)

data class CallInfo(val name: String, val number: String, val dir: String)

fun callInfo(ctx: Context, f: File): CallInfo? {
    if (ctx.checkSelfPermission(Manifest.permission.READ_CALL_LOG) != android.content.pm.PackageManager.PERMISSION_GRANTED) return null
    val start = try {
        SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).parse(f.name.substring(4, 19))!!.time
    } catch (e: Exception) { return null }
    try {
        ctx.contentResolver.query(
            CallLog.Calls.CONTENT_URI,
            arrayOf(CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME, CallLog.Calls.TYPE, CallLog.Calls.DATE, CallLog.Calls.DURATION),
            "${CallLog.Calls.DATE} <= ?", arrayOf((start + 5000).toString()), "${CallLog.Calls.DATE} DESC"
        )?.use { c ->
            if (!c.moveToFirst()) return null
            val date = c.getLong(3)
            val dur = c.getLong(4)
            if (start > date + dur * 1000 + 90000) return null
            val dir = when (c.getInt(2)) { CallLog.Calls.INCOMING_TYPE -> "واردة"; CallLog.Calls.OUTGOING_TYPE -> "صادرة"; else -> "" }
            return CallInfo(c.getString(1) ?: "", c.getString(0) ?: "", dir)
        }
    } catch (e: Exception) {}
    return null
}

fun csv(v: String) = "\"" + v.replace("\"", "\"\"") + "\""

fun buildBackup(ctx: Context, out: java.io.OutputStream, files: List<File>) {
    ZipOutputStream(out.buffered()).use { z ->
        val sb = StringBuilder("\uFEFFالملف,الاسم,الرقم,النوع,التاريخ,المدة,الحجم (ك.ب)\n")
        val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
        for (f in files) {
            z.putNextEntry(ZipEntry("recordings/" + f.name))
            f.inputStream().use { it.copyTo(z) }
            z.closeEntry()
            val i = callInfo(ctx, f)
            sb.append(listOf(f.name, i?.name ?: "", i?.number ?: "", i?.dir ?: "", fmt.format(Date(f.lastModified())), durText(f), (f.length() / 1024).toString())
                .joinToString(",") { csv(it) }).append("\n")
        }
        z.putNextEntry(ZipEntry("info.csv"))
        z.write(sb.toString().toByteArray(Charsets.UTF_8))
        z.closeEntry()
    }
}

fun durText(f: File): String = try {
    val r = MediaMetadataRetriever()
    r.setDataSource(f.path)
    val ms = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLong() ?: 0L
    r.release()
    "%02d:%02d".format(ms / 60000, (ms / 1000) % 60)
} catch (e: Exception) { "--:--" }

fun accessibilityOn(ctx: Context): Boolean {
    val s = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
    return s.contains(ctx.packageName + "/" + CallAccessibilityService::class.java.name)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                MaterialTheme(colorScheme = lightColorScheme(primary = Teal, background = Bg, surface = Color.White, onBackground = Ink, onSurface = Ink)) { App() }
            }
        }
    }
}

@Composable
fun App() {
    var screen by remember { mutableStateOf("main") }
    if (screen == "settings") {
        BackHandler { screen = "main" }
        SettingsScreen(onBack = { screen = "main" })
    } else MainScreen(onSettings = { screen = "settings" })
}

@Composable
fun askPermsLauncher(): () -> Unit {
    val perms = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }
    return {
        val p = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_PHONE_STATE, Manifest.permission.READ_CALL_LOG)
        if (Build.VERSION.SDK_INT >= 33) p += Manifest.permission.POST_NOTIFICATIONS
        perms.launch(p.toTypedArray())
    }
}

@Composable
fun MainScreen(onSettings: () -> Unit) {
    val ctx = LocalContext.current
    val recording by RecorderService.recording
    var files by remember { mutableStateOf(listOf<File>()) }
    var infos by remember { mutableStateOf(mapOf<String, CallInfo>()) }
    var playingFile by remember { mutableStateOf<File?>(null) }
    val player = remember { arrayOfNulls<MediaPlayer>(1) }

    fun refresh() {
        files = RecorderService.dir(ctx).listFiles()?.sortedByDescending { it.lastModified() } ?: emptyList()
        infos = files.mapNotNull { f -> callInfo(ctx, f)?.let { f.name to it } }.toMap()
    }
    LaunchedEffect(recording) {
        refresh()
        if (!recording) { delay(3000); refresh() }
    }
    DisposableEffect(Unit) { onDispose { player[0]?.release() } }

    val perms = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (r[Manifest.permission.RECORD_AUDIO] == true)
            ctx.startForegroundService(RecorderService.intent(ctx, RecorderService.START))
    }
    fun startManual() {
        val p = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_PHONE_STATE, Manifest.permission.READ_CALL_LOG)
        if (Build.VERSION.SDK_INT >= 33) p += Manifest.permission.POST_NOTIFICATIONS
        perms.launch(p.toTypedArray())
    }
    fun play(f: File) {
        player[0]?.release()
        if (playingFile == f) { playingFile = null; return }
        player[0] = MediaPlayer().apply {
            setDataSource(f.path); prepare(); start()
            setOnCompletionListener { playingFile = null }
        }
        playingFile = f
    }

    Column(Modifier.fillMaxSize().background(Bg).statusBarsPadding().padding(horizontal = 24.dp)) {
        Spacer(Modifier.height(20.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("التسجيلات", fontSize = 32.sp, fontWeight = FontWeight.ExtraBold, color = Ink)
                Text("${files.size} تسجيلات", fontSize = 14.sp, color = Muted)
            }
            TextButton(onClick = {
                if (recording) ctx.startService(RecorderService.intent(ctx, RecorderService.STOP)) else startManual()
            }) { Text(if (recording) "إيقاف التسجيل" else "تسجيل يدوي", color = Teal, fontWeight = FontWeight.Bold) }
            IconButton(onClick = onSettings) {
                Icon(painterResource(R.drawable.ic_settings), contentDescription = "الإعدادات", tint = Ink)
            }
        }
        Spacer(Modifier.height(10.dp))
        LazyColumn(Modifier.fillMaxSize()) {
            items(files) { f ->
                val i = infos[f.name]
                val title = when {
                    i == null -> "تسجيل"
                    i.name.isNotBlank() -> i.name
                    i.number.isNotBlank() -> i.number
                    else -> "رقم مجهول"
                }
                val dirMark = when (i?.dir) { "واردة" -> "↙ واردة"; "صادرة" -> "↗ صادرة"; else -> "" }
                val num = if (i != null && i.name.isNotBlank()) i.number else ""
                val meta = listOf(dirMark, num, SimpleDateFormat("MM/dd  HH:mm", Locale.getDefault()).format(Date(f.lastModified())))
                    .filter { it.isNotEmpty() }.joinToString(" · ")
                Column {
                    Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(44.dp).clip(CircleShape).background(Color(0xFFF1F0EE)), contentAlignment = Alignment.Center) {
                            Text(title.firstOrNull()?.toString() ?: "#", fontWeight = FontWeight.Bold, fontSize = 17.sp, color = Ink)
                        }
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(title, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Ink)
                            Text(meta, fontSize = 13.sp, color = Muted)
                        }
                        Text(durText(f), fontSize = 14.sp, color = Muted)
                        TextButton(onClick = { play(f) }) { Text(if (playingFile == f) "إيقاف" else "تشغيل", color = Teal, fontWeight = FontWeight.Bold) }
                        TextButton(onClick = {
                            if (playingFile == f) { player[0]?.release(); playingFile = null }
                            f.delete(); refresh()
                        }) { Text("حذف", color = Muted) }
                    }
                    HorizontalDivider(color = Line)
                }
            }
        }
    }
}

@Composable
fun SectionLabel(t: String) {
    Text(t, fontSize = 13.sp, color = Muted, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 26.dp, bottom = 8.dp))
}

@Composable
fun SettingsScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val askPerms = askPermsLauncher()
    var accOn by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }
    LaunchedEffect(Unit) { while (true) { accOn = accessibilityOn(ctx); delay(1500) } }

    val saver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) {
            busy = true; msg = "جارٍ إنشاء النسخة..."
            scope.launch {
                val ok = withContext(Dispatchers.IO) {
                    try {
                        val files = RecorderService.dir(ctx).listFiles()?.sortedBy { it.lastModified() } ?: emptyList()
                        ctx.contentResolver.openOutputStream(uri)!!.use { buildBackup(ctx, it, files) }
                        files.size
                    } catch (e: Exception) { -1 }
                }
                msg = if (ok >= 0) "تم الحفظ ($ok تسجيل)" else "تعذّر إنشاء النسخة"
                busy = false
            }
        }
    }

    Column(Modifier.fillMaxSize().background(Bg).statusBarsPadding().padding(horizontal = 24.dp)) {
        Spacer(Modifier.height(14.dp))
        TextButton(onClick = onBack, contentPadding = PaddingValues(0.dp)) { Text("‹ رجوع", color = Teal, fontWeight = FontWeight.Bold, fontSize = 16.sp) }
        Text("الإعدادات", fontSize = 32.sp, fontWeight = FontWeight.ExtraBold, color = Ink)

        SectionLabel("التسجيل التلقائي")
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Color.White)
                .border(1.dp, Line, RoundedCornerShape(20.dp)).padding(horizontal = 18.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(10.dp).clip(CircleShape).background(if (accOn) Teal else Color(0xFFA8A29E)))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("تسجيل المكالمات تلقائياً", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Ink)
                Text(if (accOn) "مفعّل · جاهز للمكالمة القادمة" else "فعّل الخدمة من إمكانية الوصول", fontSize = 13.sp, color = Muted)
            }
            Switch(
                checked = accOn,
                onCheckedChange = {
                    askPerms()
                    ctx.startActivity(android.content.Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                },
                colors = SwitchDefaults.colors(
                    checkedTrackColor = Teal, checkedThumbColor = Color.White, checkedBorderColor = Color.Transparent,
                    uncheckedTrackColor = Color(0xFFD6D3D1), uncheckedThumbColor = Color.White, uncheckedBorderColor = Color.Transparent
                )
            )
        }
        Text(
            "قد يشترط نظام بلدك إبلاغ الطرف الآخر قبل التسجيل. تأكد من ذلك قبل التفعيل.",
            fontSize = 13.sp, color = Muted, modifier = Modifier.padding(top = 10.dp, start = 4.dp, end = 4.dp)
        )

        SectionLabel("النسخ الاحتياطي")
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Color.White)
                .border(1.dp, Line, RoundedCornerShape(20.dp)).padding(horizontal = 18.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("نسخة احتياطية (ZIP)", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Ink)
                Text("كل التسجيلات مع الاسم والرقم والتاريخ والمدة", fontSize = 13.sp, color = Muted)
            }
            Button(
                enabled = !busy,
                onClick = { saver.launch("CallRec_" + SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date()) + ".zip") },
                colors = ButtonDefaults.buttonColors(containerColor = Teal)
            ) { Text("إنشاء") }
        }
        if (msg.isNotEmpty()) Text(msg, fontSize = 13.sp, color = Muted, modifier = Modifier.padding(top = 10.dp, start = 4.dp))
    }
}
