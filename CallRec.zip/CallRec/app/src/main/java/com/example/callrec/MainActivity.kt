package com.example.callrec

import android.Manifest
import android.media.MediaPlayer
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import android.provider.CallLog
import kotlinx.coroutines.delay
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

fun callLabel(ctx: android.content.Context, f: File): String? {
    if (ctx.checkSelfPermission(Manifest.permission.READ_CALL_LOG) != android.content.pm.PackageManager.PERMISSION_GRANTED) return null
    val start = try {
        SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).parse(f.name.substring(4, 19))!!.time
    } catch (e: Exception) { return null }
    try {
        ctx.contentResolver.query(
            CallLog.Calls.CONTENT_URI,
            arrayOf(CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME, CallLog.Calls.TYPE, CallLog.Calls.DATE, CallLog.Calls.DURATION),
            "${CallLog.Calls.DATE} <= ?", arrayOf((start + 5000).toString()), "${CallLog.Calls.DATE} DESC LIMIT 1"
        )?.use { c ->
            if (!c.moveToFirst()) return null
            val number = c.getString(0) ?: ""
            val name = c.getString(1) ?: ""
            val type = c.getInt(2)
            val date = c.getLong(3)
            val dur = c.getLong(4)
            if (start > date + dur * 1000 + 90000) return null
            val who = when {
                name.isNotBlank() && number.isNotBlank() -> "$name ($number)"
                name.isNotBlank() -> name
                number.isNotBlank() -> number
                else -> "رقم مجهول"
            }
            val dir = when (type) { CallLog.Calls.INCOMING_TYPE -> "واردة"; CallLog.Calls.OUTGOING_TYPE -> "صادرة"; else -> "" }
            return if (dir.isEmpty()) who else "$who · $dir"
        }
    } catch (e: Exception) {}
    return null
}

private val Teal = Color(0xFF0E7C86)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                MaterialTheme(colorScheme = lightColorScheme(primary = Teal)) { App() }
            }
        }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val recording by RecorderService.recording
    var files by remember { mutableStateOf(listOf<File>()) }
    var labels by remember { mutableStateOf(mapOf<String, String>()) }
    var playingFile by remember { mutableStateOf<File?>(null) }
    val player = remember { arrayOfNulls<MediaPlayer>(1) }

    fun refresh() {
        files = RecorderService.dir(ctx).listFiles()?.sortedByDescending { it.lastModified() } ?: emptyList()
        labels = files.mapNotNull { f -> callLabel(ctx, f)?.let { f.name to it } }.toMap()
    }
    LaunchedEffect(recording) {
        refresh()
        if (!recording) { delay(3000); refresh() }
    }
    DisposableEffect(Unit) { onDispose { player[0]?.release() } }

    val perms = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (r[Manifest.permission.RECORD_AUDIO] == true)
            ctx.startForegroundService(RecorderService.intent(ctx, RecorderService.START))
    }

    fun play(f: File) {
        player[0]?.release()
        if (playingFile == f) { playingFile = null; return }
        player[0] = MediaPlayer().apply {
            setDataSource(f.path); prepare(); start()
            setOnCompletionListener { playingFile = null }
        }
        playingFile = f
    }

    Column(Modifier.fillMaxSize().padding(20.dp).statusBarsPadding(), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("تسجيلاتي", style = MaterialTheme.typography.headlineMedium)
        Text(
            "للتسجيل التلقائي: اضغط الزر أدناه، ثم فعّل «مسجّل المكالمات» ضمن الخدمات المثبتة. أبلغ الطرف الآخر قبل التسجيل.",
            style = MaterialTheme.typography.bodyMedium, color = Color(0xFF475569)
        )
        OutlinedButton(
            onClick = {
                ctx.startActivity(android.content.Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS))
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("تفعيل التسجيل التلقائي (إعدادات إمكانية الوصول)") }
        Button(
            onClick = {
                if (recording) ctx.startService(RecorderService.intent(ctx, RecorderService.STOP))
                else {
                    val p = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_PHONE_STATE, Manifest.permission.READ_CALL_LOG)
                    if (Build.VERSION.SDK_INT >= 33) p += Manifest.permission.POST_NOTIFICATIONS
                    perms.launch(p.toTypedArray())
                }
            },
            colors = ButtonDefaults.buttonColors(containerColor = if (recording) Color(0xFFD93A3A) else Teal),
            modifier = Modifier.fillMaxWidth().height(56.dp)
        ) { Text(if (recording) "إيقاف التسجيل" else "بدء التسجيل") }

        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(files) { f ->
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(labels[f.name] ?: "تسجيل", style = MaterialTheme.typography.titleSmall)
                            Text(
                                SimpleDateFormat("yyyy/MM/dd  HH:mm", Locale.getDefault()).format(Date(f.lastModified())) + " · ${f.length() / 1024} ك.ب",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                        TextButton(onClick = { play(f) }) { Text(if (playingFile == f) "إيقاف" else "تشغيل") }
                        TextButton(onClick = {
                            if (playingFile == f) { player[0]?.release(); playingFile = null }
                            f.delete(); refresh()
                        }) { Text("حذف", color = Color(0xFFB42323)) }
                    }
                }
            }
        }
    }
}
