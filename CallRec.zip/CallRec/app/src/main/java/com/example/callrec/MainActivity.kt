package com.example.callrec

import android.Manifest
import android.content.Context
import android.content.res.Configuration
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.*
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

object Pal {
    var dark = false
    private fun c(l: Long, d: Long) = Color(if (dark) d else l)
    val Bg get() = c(0xFFF7F8F7, 0xFF0F1414)
    val Card get() = c(0xFFFFFFFF, 0xFF181E1E)
    val Tonal get() = c(0xFFE9EEED, 0xFF242C2C)
    val Ink get() = c(0xFF191C1C, 0xFFE3E9E8)
    val Muted get() = c(0xFF5F6868, 0xFF9AA6A5)
    val Teal get() = c(0xFF0E7C86, 0xFF4DB6BF)
    val OnTeal get() = c(0xFFFFFFFF, 0xFF00363B)
    val TealTonal get() = c(0xFFCFEBEE, 0xFF00494F)
    val OnTealTonal get() = c(0xFF00363B, 0xFFCFEBEE)
    val Sel get() = c(0xFFE4F3F4, 0xFF12302F)
    val Track get() = c(0xFFDCE3E2, 0xFF3A4443)
    val Off get() = c(0xFFC9CFCE, 0xFF4B5655)
    val Rec = Color(0xFFD93A3A)
}

data class CallInfo(val name: String, val number: String, val dir: String)

fun callInfo(ctx: Context, f: File): CallInfo? = CallInfoStore.get(ctx, f)

fun normQ(s: String): String = s.map { c ->
    when (c) {
        in '\u0660'..'\u0669' -> '0' + (c - '\u0660')
        in '\u06F0'..'\u06F9' -> '0' + (c - '\u06F0')
        else -> c
    }
}.joinToString("").lowercase()

fun csv(v: String) = "\"" + v.replace("\"", "\"\"") + "\""

fun cleanName(v: String) = v.replace(Regex("[\\\\/:*?\"<>|\\n\\r]"), " ").trim().replace(Regex("\\s+"), "_")

fun buildBackup(ctx: Context, out: java.io.OutputStream, files: List<File>) {
    ZipOutputStream(out.buffered()).use { z ->
        val sb = StringBuilder("\uFEFFالملف,الاسم,الرقم,النوع,التاريخ,المدة,الحجم (ك.ب)\n")
        val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
        val nameFmt = SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US)
        val used = HashSet<String>()
        for (f in files) {
            val i = callInfo(ctx, f)
            val whenMs = CallInfoStore.startOf(f) ?: f.lastModified()
            val parts = mutableListOf(nameFmt.format(Date(whenMs)))
            if (i != null && i.name.isNotBlank()) parts += cleanName(i.name)
            if (i != null && i.number.isNotBlank()) parts += cleanName(i.number)
            if (parts.size == 1) parts += "غير_معروف"
            var base = parts.joinToString("_")
            var n = 2
            while (!used.add(base)) { base = parts.joinToString("_") + "_" + n; n++ }
            val entryName = base + ".m4a"
            z.putNextEntry(ZipEntry("recordings/" + entryName))
            f.inputStream().use { it.copyTo(z) }
            z.closeEntry()
            sb.append(listOf(entryName, i?.name ?: "", i?.number ?: "", i?.dir ?: "", fmt.format(Date(whenMs)), durText(f), (f.length() / 1024).toString())
                .joinToString(",") { csv(it) }).append("\n")
        }
        z.putNextEntry(ZipEntry("info.csv"))
        z.write(sb.toString().toByteArray(Charsets.UTF_8))
        z.closeEntry()
    }
}

fun durText(f: File): String = try {
    val r = MediaMetadataRetriever()
    r.setDataSource(f.path)
    val ms = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLong() ?: 0L
    r.release()
    "%d:%02d".format(ms / 60000, (ms / 1000) % 60)
} catch (e: Exception) { "--:--" }

fun fmtMs(ms: Int) = "%d:%02d".format(ms / 60000, (ms / 1000) % 60)

fun accessibilityOn(ctx: Context): Boolean {
    val s = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
    return s.contains(ctx.packageName + "/" + CallAccessibilityService::class.java.name)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        Pal.dark = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        setContent {
            val scheme = if (Pal.dark) darkColorScheme(
                primary = Pal.Teal, onPrimary = Pal.OnTeal, background = Pal.Bg, surface = Pal.Card, onBackground = Pal.Ink, onSurface = Pal.Ink
            ) else lightColorScheme(
                primary = Pal.Teal, onPrimary = Pal.OnTeal, background = Pal.Bg, surface = Pal.Card, onBackground = Pal.Ink, onSurface = Pal.Ink
            )
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                MaterialTheme(colorScheme = scheme) { App() }
            }
        }
    }
}

@Composable
fun Ic(id: Int, tint: Color, size: Dp = 24.dp, desc: String? = null) {
    Icon(painterResource(id), desc, Modifier.size(size), tint)
}

@Composable
fun RoundBtn(id: Int, desc: String, bg: Color, tint: Color, size: Dp = 48.dp, onClick: () -> Unit) {
    Box(Modifier.size(size).clip(CircleShape).background(bg).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Ic(id, tint, 24.dp, desc)
    }
}

@Composable
fun App() {
    var screen by remember { mutableStateOf("main") }
    if (screen == "settings") {
        BackHandler { screen = "main" }
        SettingsScreen(onBack = { screen = "main" })
    } else MainScreen(onSettings = { screen = "settings" })
}

@Composable
fun askPermsLauncher(): () -> Unit {
    val perms = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }
    return {
        val p = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_PHONE_STATE, Manifest.permission.READ_CALL_LOG)
        if (Build.VERSION.SDK_INT >= 33) p += Manifest.permission.POST_NOTIFICATIONS
        perms.launch(p.toTypedArray())
    }
}

@Composable
fun MainScreen(onSettings: () -> Unit) {
    val ctx = LocalContext.current
    val recording by RecorderService.recording
    var files by remember { mutableStateOf(listOf<File>()) }
    var infos by remember { mutableStateOf(mapOf<String, CallInfo>()) }
    var playingFile by remember { mutableStateOf<File?>(null) }
    val player = remember { arrayOfNulls<MediaPlayer>(1) }
    var isPlaying by remember { mutableStateOf(false) }
    var pos by remember { mutableStateOf(0) }
    var total by remember { mutableStateOf(0) }
    var speed by remember { mutableStateOf(1f) }
    var searching by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    val fr = remember { FocusRequester() }
    LaunchedEffect(searching) { if (searching) fr.requestFocus() }

    fun refresh() {
        files = RecorderService.dir(ctx).listFiles()?.filter { it.extension == "m4a" }?.sortedByDescending { it.lastModified() } ?: emptyList()
        infos = files.mapNotNull { f -> callInfo(ctx, f)?.let { f.name to it } }.toMap()
    }
    LaunchedEffect(recording) {
        refresh()
        if (!recording) { delay(3000); refresh() }
    }
    DisposableEffect(Unit) { onDispose { player[0]?.release() } }

    val perms = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (r[Manifest.permission.RECORD_AUDIO] == true)
            ctx.startForegroundService(RecorderService.intent(ctx, RecorderService.START))
    }
    fun startManual() {
        val p = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_PHONE_STATE, Manifest.permission.READ_CALL_LOG)
        if (Build.VERSION.SDK_INT >= 33) p += Manifest.permission.POST_NOTIFICATIONS
        perms.launch(p.toTypedArray())
    }
    fun applySpeed() {
        val mp = player[0] ?: return
        try {
            val was = mp.isPlaying
            mp.playbackParams = mp.playbackParams.setSpeed(speed)
            if (!was) mp.pause()
        } catch (_: Exception) {}
    }
    fun togglePlay() {
        val mp = player[0] ?: return
        if (mp.isPlaying) { mp.pause(); isPlaying = false } else { mp.start(); applySpeed(); isPlaying = true }
    }
    fun closePlayer() {
        player[0]?.release(); player[0] = null
        playingFile = null; isPlaying = false
    }
    fun play(f: File) {
        if (playingFile == f) { togglePlay(); return }
        player[0]?.release(); player[0] = null
        val mp = MediaPlayer()
        mp.setDataSource(f.path); mp.prepare()
        total = mp.duration; pos = 0
        mp.setOnCompletionListener { isPlaying = false; pos = 0; it.seekTo(0) }
        mp.start(); player[0] = mp; applySpeed()
        isPlaying = true; playingFile = f
    }
    fun skip(ms: Int) {
        val mp = player[0] ?: return
        val t = (mp.currentPosition + ms).coerceIn(0, total)
        mp.seekTo(t); pos = t
    }
    LaunchedEffect(playingFile, isPlaying) {
        while (isPlaying) { player[0]?.let { pos = it.currentPosition }; delay(250) }
    }

    val shown = if (query.isBlank()) files else {
        val toks = normQ(query).split(" ").filter { it.isNotBlank() }
        files.filter { f ->
            val i = infos[f.name]
            val d = Date(CallInfoStore.startOf(f) ?: f.lastModified())
            val hay = normQ(listOf(
                i?.name ?: "", i?.number ?: "", (i?.number ?: "").filter { it.isDigit() }, i?.dir ?: "",
                SimpleDateFormat("yyyy-MM-dd yyyy/MM/dd dd/MM/yyyy MM/dd HH:mm", Locale.US).format(d)
            ).joinToString(" "))
            toks.all { hay.contains(it) }
        }
    }

    fun titleOf(f: File): String {
        val i = infos[f.name]
        return when {
            i == null -> "تسجيل"
            i.name.isNotBlank() -> i.name
            i.number.isNotBlank() -> i.number
            else -> "رقم مجهول"
        }
    }
    fun metaOf(f: File): String {
        val i = infos[f.name]
        val num = if (i != null && i.name.isNotBlank()) i.number else ""
        return listOf(num, SimpleDateFormat("MM/dd  HH:mm", Locale.getDefault()).format(Date(f.lastModified())))
            .filter { it.isNotEmpty() }.joinToString(" · ")
    }

    Box(Modifier.fillMaxSize().background(Pal.Bg)) {
        Column(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 20.dp)) {
            Spacer(Modifier.height(14.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                RoundBtn(R.drawable.ic_search, "بحث", if (searching) Pal.TealTonal else Pal.Tonal, if (searching) Pal.OnTealTonal else Pal.Ink) {
                    searching = !searching; if (!searching) query = ""
                }
                Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                    Text("التسجيلات", fontSize = 32.sp, fontWeight = FontWeight.ExtraBold, color = Pal.Ink)
                    Text(if (query.isBlank()) "${files.size} تسجيلات" else "${shown.size} من ${files.size}", fontSize = 14.sp, color = Pal.Muted)
                }
                RoundBtn(R.drawable.ic_settings, "الإعدادات", Pal.Tonal, Pal.Ink, onClick = onSettings)
            }
            if (searching) {
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = query, onValueChange = { query = it }, singleLine = true,
                    placeholder = { Text("ابحث بالاسم أو الرقم أو التاريخ", color = Pal.Muted, fontSize = 14.sp) },
                    shape = RoundedCornerShape(28.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Pal.Teal, unfocusedBorderColor = Color.Transparent,
                        focusedContainerColor = Pal.Tonal, unfocusedContainerColor = Pal.Tonal,
                        focusedTextColor = Pal.Ink, unfocusedTextColor = Pal.Ink, cursorColor = Pal.Teal
                    ),
                    modifier = Modifier.fillMaxWidth().focusRequester(fr)
                )
            }
            LazyColumn(
                Modifier.fillMaxSize(),
                contentPadding = PaddingValues(top = 14.dp, bottom = if (playingFile != null) 340.dp else 110.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (shown.isEmpty() && query.isNotBlank()) item { Text("لا توجد نتائج", color = Pal.Muted, fontSize = 15.sp, modifier = Modifier.padding(top = 20.dp)) }
                items(shown) { f ->
                    val i = infos[f.name]
                    val title = titleOf(f)
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp))
                            .background(if (playingFile == f) Pal.Sel else Pal.Card).padding(horizontal = 14.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(Modifier.size(48.dp).clip(CircleShape).background(Pal.Tonal), contentAlignment = Alignment.Center) {
                            Text(title.firstOrNull()?.toString() ?: "#", fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, color = Pal.Ink)
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(title, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Pal.Ink, maxLines = 1)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                when (i?.dir) {
                                    "واردة" -> { Ic(R.drawable.ic_in, Pal.Muted, 14.dp, "واردة"); Spacer(Modifier.width(4.dp)) }
                                    "صادرة" -> { Ic(R.drawable.ic_out, Pal.Muted, 14.dp, "صادرة"); Spacer(Modifier.width(4.dp)) }
                                }
                                Text(metaOf(f), fontSize = 13.sp, color = Pal.Muted, maxLines = 1)
                            }
                        }
                        Text(durText(f), fontSize = 13.sp, color = Pal.Muted)
                        Spacer(Modifier.width(8.dp))
                        RoundBtn(
                            if (playingFile == f && isPlaying) R.drawable.ic_pause else R.drawable.ic_play,
                            if (playingFile == f && isPlaying) "إيقاف مؤقت" else "تشغيل", Pal.TealTonal, Pal.OnTealTonal, 44.dp
                        ) { play(f) }
                        RoundBtn(R.drawable.ic_delete, "حذف", Color.Transparent, Pal.Muted, 44.dp) {
                            if (playingFile == f) closePlayer()
                            f.delete(); File(f.path + ".info").delete(); refresh()
                        }
                    }
                }
            }
        }

        val cur = playingFile
        if (cur == null) {
            Box(
                Modifier.align(Alignment.BottomEnd).navigationBarsPadding().padding(22.dp).size(64.dp)
                    .clip(RoundedCornerShape(22.dp)).background(if (recording) Pal.Rec else Pal.Teal)
                    .clickable {
                        if (recording) ctx.startService(RecorderService.intent(ctx, RecorderService.STOP)) else startManual()
                    },
                contentAlignment = Alignment.Center
            ) {
                Ic(if (recording) R.drawable.ic_stop else R.drawable.ic_mic, if (recording) Color.White else Pal.OnTeal, 28.dp,
                    if (recording) "إيقاف التسجيل" else "تسجيل يدوي")
            }
        } else {
            Column(
                Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                    .clip(RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp)).background(Pal.Card)
                    .navigationBarsPadding().padding(start = 22.dp, end = 22.dp, top = 12.dp, bottom = 18.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(Modifier.width(36.dp).height(4.dp).clip(RoundedCornerShape(2.dp)).background(Pal.Off).align(Alignment.CenterHorizontally))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(48.dp).clip(CircleShape).background(Pal.TealTonal), contentAlignment = Alignment.Center) {
                        Text(titleOf(cur).firstOrNull()?.toString() ?: "#", fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, color = Pal.OnTealTonal)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(titleOf(cur), fontSize = 17.sp, fontWeight = FontWeight.ExtraBold, color = Pal.Ink, maxLines = 1)
                        Text(metaOf(cur), fontSize = 13.sp, color = Pal.Muted, maxLines = 1)
                    }
                    RoundBtn(R.drawable.ic_close, "إغلاق", Pal.Tonal, Pal.Ink) { closePlayer() }
                }
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    Slider(
                        value = pos.toFloat().coerceIn(0f, maxOf(total, 1).toFloat()),
                        onValueChange = { player[0]?.seekTo(it.toInt()); pos = it.toInt() },
                        valueRange = 0f..maxOf(total, 1).toFloat(),
                        colors = SliderDefaults.colors(thumbColor = Pal.Teal, activeTrackColor = Pal.Teal, inactiveTrackColor = Pal.Track)
                    )
                    Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(fmtMs(pos), fontSize = 12.5.sp, color = Pal.Muted)
                        Text(fmtMs(total), fontSize = 12.5.sp, color = Pal.Muted)
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(52.dp).clip(CircleShape).background(Pal.Tonal).clickable { skip(-10000) }, contentAlignment = Alignment.Center) {
                            Ic(R.drawable.ic_replay, Pal.Ink, 30.dp, "رجوع 10 ثوان")
                            Text("10", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = Pal.Ink)
                        }
                        Spacer(Modifier.width(22.dp))
                        Box(Modifier.size(72.dp).clip(RoundedCornerShape(28.dp)).background(Pal.Teal).clickable { togglePlay() }, contentAlignment = Alignment.Center) {
                            Ic(if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play, Pal.OnTeal, 34.dp, if (isPlaying) "إيقاف مؤقت" else "تشغيل")
                        }
                        Spacer(Modifier.width(22.dp))
                        Box(Modifier.size(52.dp).clip(CircleShape).background(Pal.Tonal).clickable { skip(10000) }, contentAlignment = Alignment.Center) {
                            Ic(R.drawable.ic_forward, Pal.Ink, 30.dp, "تقديم 10 ثوان")
                            Text("10", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = Pal.Ink)
                        }
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally)) {
                    listOf(0.5f to "0.5", 1f to "1", 1.5f to "1.5", 2f to "2").forEach { (v, label) ->
                        val sel = speed == v
                        Box(
                            Modifier.heightIn(min = 44.dp).clip(RoundedCornerShape(22.dp))
                                .background(if (sel) Pal.Teal else Pal.Tonal)
                                .clickable { speed = v; applySpeed() }.padding(horizontal = 16.dp),
                            contentAlignment = Alignment.Center
                        ) { Text(label + "×", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = if (sel) Pal.OnTeal else Pal.Ink) }
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val askPerms = askPermsLauncher()
    var accOn by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }
    LaunchedEffect(Unit) { while (true) { accOn = accessibilityOn(ctx); delay(1500) } }

    val saver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) {
            busy = true; msg = "جارٍ إنشاء النسخة..."
            scope.launch {
                val ok = withContext(Dispatchers.IO) {
                    try {
                        val files = RecorderService.dir(ctx).listFiles()?.filter { it.extension == "m4a" }?.sortedBy { it.lastModified() } ?: emptyList()
                        ctx.contentResolver.openOutputStream(uri)!!.use { buildBackup(ctx, it, files) }
                        files.size
                    } catch (e: Exception) { -1 }
                }
                msg = if (ok >= 0) "تم الحفظ ($ok تسجيل)" else "تعذّر إنشاء النسخة"
                busy = false
            }
        }
    }

    Column(Modifier.fillMaxSize().background(Pal.Bg).statusBarsPadding().padding(horizontal = 20.dp)) {
        Spacer(Modifier.height(14.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            RoundBtn(R.drawable.ic_back, "رجوع", Pal.Tonal, Pal.Ink, onClick = onBack)
            Spacer(Modifier.width(12.dp))
            Text("الإعدادات", fontSize = 32.sp, fontWeight = FontWeight.ExtraBold, color = Pal.Ink)
        }
        Spacer(Modifier.height(22.dp))
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(Pal.Card).padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(48.dp).clip(CircleShape).background(Pal.TealTonal), contentAlignment = Alignment.Center) {
                Ic(R.drawable.ic_mic, Pal.OnTealTonal)
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text("التسجيل التلقائي", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Pal.Ink)
                Text(if (accOn) "مفعّل · جاهز للمكالمة القادمة" else "فعّل الخدمة من إمكانية الوصول", fontSize = 13.sp, color = Pal.Muted)
            }
            Switch(
                checked = accOn,
                onCheckedChange = {
                    askPerms()
                    ctx.startActivity(android.content.Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                },
                colors = SwitchDefaults.colors(
                    checkedTrackColor = Pal.Teal, checkedThumbColor = Pal.OnTeal, checkedBorderColor = Color.Transparent,
                    uncheckedTrackColor = Pal.Off, uncheckedThumbColor = Pal.Card, uncheckedBorderColor = Color.Transparent
                )
            )
        }
        Spacer(Modifier.height(10.dp))
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(Pal.Card).padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(48.dp).clip(CircleShape).background(Pal.TealTonal), contentAlignment = Alignment.Center) {
                Ic(R.drawable.ic_download, Pal.OnTealTonal)
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text("نسخة احتياطية", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Pal.Ink)
                Text("ملف ZIP بكل التسجيلات ومعلوماتها", fontSize = 13.sp, color = Pal.Muted)
            }
            RoundBtn(R.drawable.ic_download, "إنشاء نسخة احتياطية", if (busy) Pal.Off else Pal.Teal, Pal.OnTeal) {
                if (!busy) saver.launch("CallRec_" + SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date()) + ".zip")
            }
        }
        if (msg.isNotEmpty()) Text(msg, fontSize = 13.sp, color = Pal.Muted, modifier = Modifier.padding(top = 10.dp, start = 8.dp))
        Text(
            "قد يشترط نظام بلدك إبلاغ الطرف الآخر قبل التسجيل. تأكد من ذلك قبل التفعيل.",
            fontSize = 13.sp, color = Pal.Muted, modifier = Modifier.padding(top = 16.dp, start = 8.dp, end = 8.dp)
        )
    }
}
