package com.example.callrec

import android.Manifest
import android.content.Context
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.os.Build
import android.os.Bundle
import android.provider.CallLog
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.res.painterResource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

private val Teal = Color(0xFF0E7C86)
private val Ink = Color(0xFF1C1917)
private val Muted = Color(0xFF78716C)
private val Line = Color(0xFFEFEDEB)
private val Bg = Color(0xFFFAFAF9)

data class CallInfo(val name: String, val number: String, val dir: String)

fun callInfo(ctx: Context, f: File): CallInfo? = CallInfoStore.get(ctx, f)

fun normQ(s: String): String = s.map { c ->
    when (c) {
        in '\u0660'..'\u0669' -> '0' + (c - '\u0660')
        in '\u06F0'..'\u06F9' -> '0' + (c - '\u06F0')
        else -> c
    }
}.joinToString("").lowercase()

fun csv(v: String) = "\"" + v.replace("\"", "\"\"") + "\""

fun cleanName(v: String) = v.replace(Regex("[\\\\/:*?\"<>|\\n\\r]"), " ").trim().replace(Regex("\\s+"), "_")

fun buildBackup(ctx: Context, out: java.io.OutputStream, files: List<File>) {
    ZipOutputStream(out.buffered()).use { z ->
        val sb = StringBuilder("\uFEFFالملف,الاسم,الرقم,النوع,التاريخ,المدة,الحجم (ك.ب)\n")
        val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
        val nameFmt = SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US)
        val used = HashSet<String>()
        for (f in files) {
            val i = callInfo(ctx, f)
            val whenMs = CallInfoStore.startOf(f) ?: f.lastModified()
            val parts = mutableListOf(nameFmt.format(Date(whenMs)))
            if (i != null && i.name.isNotBlank()) parts += cleanName(i.name)
            if (i != null && i.number.isNotBlank()) parts += cleanName(i.number)
            if (parts.size == 1) parts += "غير_معروف"
            var base = parts.joinToString("_")
            var n = 2
            while (!used.add(base)) { base = parts.joinToString("_") + "_" + n; n++ }
            val entryName = base + ".m4a"
            z.putNextEntry(ZipEntry("recordings/" + entryName))
            f.inputStream().use { it.copyTo(z) }
            z.closeEntry()
            sb.append(listOf(entryName, i?.name ?: "", i?.number ?: "", i?.dir ?: "", fmt.format(Date(whenMs)), durText(f), (f.length() / 1024).toString())
                .joinToString(",") { csv(it) }).append("\n")
        }
        z.putNextEntry(ZipEntry("info.csv"))
        z.write(sb.toString().toByteArray(Charsets.UTF_8))
        z.closeEntry()
    }
}

fun durText(f: File): String = try {
    val r = MediaMetadataRetriever()
    r.setDataSource(f.path)
    val ms = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLong() ?: 0L
    r.release()
    "%02d:%02d".format(ms / 60000, (ms / 1000) % 60)
} catch (e: Exception) { "--:--" }

fun accessibilityOn(ctx: Context): Boolean {
    val s = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
    return s.contains(ctx.packageName + "/" + CallAccessibilityService::class.java.name)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                MaterialTheme(colorScheme = lightColorScheme(primary = Teal, background = Bg, surface = Color.White, onBackground = Ink, onSurface = Ink)) { App() }
            }
        }
    }
}

@Composable
fun App() {
    var screen by remember { mutableStateOf("main") }
    if (screen == "settings") {
        BackHandler { screen = "main" }
        SettingsScreen(onBack = { screen = "main" })
    } else MainScreen(onSettings = { screen = "settings" })
}

@Composable
fun askPermsLauncher(): () -> Unit {
    val perms = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }
    return {
        val p = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_PHONE_STATE, Manifest.permission.READ_CALL_LOG)
        if (Build.VERSION.SDK_INT >= 33) p += Manifest.permission.POST_NOTIFICATIONS
        perms.launch(p.toTypedArray())
    }
}

@Composable
fun MainScreen(onSettings: () -> Unit) {
    val ctx = LocalContext.current
    val recording by RecorderService.recording
    var files by remember { mutableStateOf(listOf<File>()) }
    var infos by remember { mutableStateOf(mapOf<String, CallInfo>()) }
    var playingFile by remember { mutableStateOf<File?>(null) }
    val player = remember { arrayOfNulls<MediaPlayer>(1) }
    var isPlaying by remember { mutableStateOf(false) }
    var pos by remember { mutableStateOf(0) }
    var total by remember { mutableStateOf(0) }
    var speed by remember { mutableStateOf(1f) }
    var searching by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    val fr = remember { FocusRequester() }
    LaunchedEffect(searching) { if (searching) fr.requestFocus() }

    fun refresh() {
        files = RecorderService.dir(ctx).listFiles()?.filter { it.extension == "m4a" }?.sortedByDescending { it.lastModified() } ?: emptyList()
        infos = files.mapNotNull { f -> callInfo(ctx, f)?.let { f.name to it } }.toMap()
    }
    LaunchedEffect(recording) {
        refresh()
        if (!recording) { delay(3000); refresh() }
    }
    DisposableEffect(Unit) { onDispose { player[0]?.release() } }

    val perms = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (r[Manifest.permission.RECORD_AUDIO] == true)
            ctx.startForegroundService(RecorderService.intent(ctx, RecorderService.START))
    }
    fun startManual() {
        val p = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_PHONE_STATE, Manifest.permission.READ_CALL_LOG)
        if (Build.VERSION.SDK_INT >= 33) p += Manifest.permission.POST_NOTIFICATIONS
        perms.launch(p.toTypedArray())
    }
    fun applySpeed() {
        val mp = player[0] ?: return
        try {
            val was = mp.isPlaying
            mp.playbackParams = mp.playbackParams.setSpeed(speed)
            if (!was) mp.pause()
        } catch (_: Exception) {}
    }
    fun play(f: File) {
        player[0]?.release(); player[0] = null
        if (playingFile == f) { playingFile = null; isPlaying = false; return }
        val mp = MediaPlayer()
        mp.setDataSource(f.path); mp.prepare()
        total = mp.duration; pos = 0
        mp.setOnCompletionListener { isPlaying = false; pos = 0; it.seekTo(0) }
        mp.start(); player[0] = mp; applySpeed()
        isPlaying = true; playingFile = f
    }
    fun togglePlay() {
        val mp = player[0] ?: return
        if (mp.isPlaying) { mp.pause(); isPlaying = false } else { mp.start(); applySpeed(); isPlaying = true }
    }
    fun skip(ms: Int) {
        val mp = player[0] ?: return
        val t = (mp.currentPosition + ms).coerceIn(0, total)
        mp.seekTo(t); pos = t
    }
    LaunchedEffect(playingFile, isPlaying) {
        while (isPlaying) { player[0]?.let { pos = it.currentPosition }; delay(250) }
    }

    val shown = if (query.isBlank()) files else {
        val toks = normQ(query).split(" ").filter { it.isNotBlank() }
        files.filter { f ->
            val i = infos[f.name]
            val d = Date(CallInfoStore.startOf(f) ?: f.lastModified())
            val hay = normQ(listOf(
                i?.name ?: "", i?.number ?: "", (i?.number ?: "").filter { it.isDigit() }, i?.dir ?: "",
                SimpleDateFormat("yyyy-MM-dd yyyy/MM/dd dd/MM/yyyy MM/dd HH:mm", Locale.US).format(d)
            ).joinToString(" "))
            toks.all { hay.contains(it) }
        }
    }

    Column(Modifier.fillMaxSize().background(Bg).statusBarsPadding().padding(horizontal = 24.dp)) {
        Spacer(Modifier.height(20.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { searching = !searching; if (!searching) query = "" }) {
                Icon(painterResource(R.drawable.ic_search), contentDescription = "بحث", tint = if (searching) Teal else Ink)
            }
            Column(Modifier.weight(1f)) {
                Text("التسجيلات", fontSize = 32.sp, fontWeight = FontWeight.ExtraBold, color = Ink)
                Text(if (query.isBlank()) "${files.size} تسجيلات" else "${shown.size} من ${files.size}", fontSize = 14.sp, color = Muted)
            }
            TextButton(onClick = {
                if (recording) ctx.startService(RecorderService.intent(ctx, RecorderService.STOP)) else startManual()
            }) { Text(if (recording) "إيقاف التسجيل" else "تسجيل يدوي", color = Teal, fontWeight = FontWeight.Bold) }
            IconButton(onClick = onSettings) {
                Icon(painterResource(R.drawable.ic_settings), contentDescription = "الإعدادات", tint = Ink)
            }
        }
        if (searching) {
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = query, onValueChange = { query = it }, singleLine = true,
                placeholder = { Text("ابحث بالاسم أو الرقم أو التاريخ", color = Muted, fontSize = 14.sp) },
                shape = RoundedCornerShape(16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Teal, unfocusedBorderColor = Color(0xFFD6D3D1),
                    focusedContainerColor = Color.White, unfocusedContainerColor = Color.White
                ),
                modifier = Modifier.fillMaxWidth().focusRequester(fr)
            )
        }
        Spacer(Modifier.height(10.dp))
        if (shown.isEmpty() && query.isNotBlank()) {
            Text("لا توجد نتائج", color = Muted, fontSize = 15.sp, modifier = Modifier.padding(top = 24.dp))
        }
        LazyColumn(Modifier.fillMaxSize()) {
            items(shown) { f ->
                val i = infos[f.name]
                val title = when {
                    i == null -> "تسجيل"
                    i.name.isNotBlank() -> i.name
                    i.number.isNotBlank() -> i.number
                    else -> "رقم مجهول"
                }
                val dirMark = when (i?.dir) { "واردة" -> "↙ واردة"; "صادرة" -> "↗ صادرة"; else -> "" }
                val num = if (i != null && i.name.isNotBlank()) i.number else ""
                val meta = listOf(dirMark, num, SimpleDateFormat("MM/dd  HH:mm", Locale.getDefault()).format(Date(f.lastModified())))
                    .filter { it.isNotEmpty() }.joinToString(" · ")
                Column {
                    Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(44.dp).clip(CircleShape).background(Color(0xFFF1F0EE)), contentAlignment = Alignment.Center) {
                            Text(title.firstOrNull()?.toString() ?: "#", fontWeight = FontWeight.Bold, fontSize = 17.sp, color = Ink)
                        }
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(title, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Ink)
                            Text(meta, fontSize = 13.sp, color = Muted)
                        }
                        Text(durText(f), fontSize = 14.sp, color = Muted)
                        TextButton(onClick = { play(f) }) { Text(if (playingFile == f) "إغلاق" else "تشغيل", color = Teal, fontWeight = FontWeight.Bold) }
                        TextButton(onClick = {
                            if (playingFile == f) { player[0]?.release(); player[0] = null; playingFile = null; isPlaying = false }
                            f.delete(); File(f.path + ".info").delete(); refresh()
                        }) { Text("حذف", color = Muted) }
                    }
                    if (playingFile == f) {
                        PlayerPanel(
                            pos = pos, total = total, playing = isPlaying, speed = speed,
                            onSeek = { player[0]?.seekTo(it); pos = it },
                            onToggle = { togglePlay() },
                            onSkip = { skip(it) },
                            onSpeed = { speed = it; applySpeed() }
                        )
                    }
                    HorizontalDivider(color = Line)
                }
            }
        }
    }
}

fun fmtMs(ms: Int) = "%d:%02d".format(ms / 60000, (ms / 1000) % 60)

@Composable
fun PlayerPanel(
    pos: Int, total: Int, playing: Boolean, speed: Float,
    onSeek: (Int) -> Unit, onToggle: () -> Unit, onSkip: (Int) -> Unit, onSpeed: (Float) -> Unit
) {
    Column(Modifier.fillMaxWidth().padding(bottom = 14.dp)) {
        Slider(
            value = pos.toFloat().coerceIn(0f, maxOf(total, 1).toFloat()),
            onValueChange = { onSeek(it.toInt()) },
            valueRange = 0f..maxOf(total, 1).toFloat(),
            colors = SliderDefaults.colors(thumbColor = Teal, activeTrackColor = Teal, inactiveTrackColor = Color(0xFFD6D3D1))
        )
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(fmtMs(pos), fontSize = 13.sp, color = Muted)
                Text(fmtMs(total), fontSize = 13.sp, color = Muted)
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { onSkip(-10000) }) { Text("-10", color = Ink, fontWeight = FontWeight.Bold) }
                Spacer(Modifier.width(8.dp))
                Button(onClick = onToggle, colors = ButtonDefaults.buttonColors(containerColor = Teal)) {
                    Text(if (playing) "إيقاف مؤقت" else "تشغيل")
                }
                Spacer(Modifier.width(8.dp))
                TextButton(onClick = { onSkip(10000) }) { Text("+10", color = Ink, fontWeight = FontWeight.Bold) }
            }
        }
        Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally)) {
            listOf(0.5f to "0.5", 1f to "1", 1.5f to "1.5", 2f to "2").forEach { (v, label) ->
                val sel = speed == v
                Box(
                    Modifier.clip(RoundedCornerShape(20.dp)).background(if (sel) Teal else Color(0xFFF1F0EE))
                        .clickable { onSpeed(v) }.padding(horizontal = 16.dp, vertical = 8.dp)
                ) { Text(label + "×", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = if (sel) Color.White else Ink) }
            }
        }
    }
}

@Composable
fun SectionLabel(t: String) {
    Text(t, fontSize = 13.sp, color = Muted, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 26.dp, bottom = 8.dp))
}

@Composable
fun SettingsScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val askPerms = askPermsLauncher()
    var accOn by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }
    LaunchedEffect(Unit) { while (true) { accOn = accessibilityOn(ctx); delay(1500) } }

    val saver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) {
            busy = true; msg = "جارٍ إنشاء النسخة..."
            scope.launch {
                val ok = withContext(Dispatchers.IO) {
                    try {
                        val files = RecorderService.dir(ctx).listFiles()?.filter { it.extension == "m4a" }?.sortedBy { it.lastModified() } ?: emptyList()
                        ctx.contentResolver.openOutputStream(uri)!!.use { buildBackup(ctx, it, files) }
                        files.size
                    } catch (e: Exception) { -1 }
                }
                msg = if (ok >= 0) "تم الحفظ ($ok تسجيل)" else "تعذّر إنشاء النسخة"
                busy = false
            }
        }
    }

    Column(Modifier.fillMaxSize().background(Bg).statusBarsPadding().padding(horizontal = 24.dp)) {
        Spacer(Modifier.height(14.dp))
        TextButton(onClick = onBack, contentPadding = PaddingValues(0.dp)) { Text("‹ رجوع", color = Teal, fontWeight = FontWeight.Bold, fontSize = 16.sp) }
        Text("الإعدادات", fontSize = 32.sp, fontWeight = FontWeight.ExtraBold, color = Ink)

        SectionLabel("التسجيل التلقائي")
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Color.White)
                .border(1.dp, Line, RoundedCornerShape(20.dp)).padding(horizontal = 18.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(10.dp).clip(CircleShape).background(if (accOn) Teal else Color(0xFFA8A29E)))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("تسجيل المكالمات تلقائياً", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Ink)
                Text(if (accOn) "مفعّل · جاهز للمكالمة القادمة" else "فعّل الخدمة من إمكانية الوصول", fontSize = 13.sp, color = Muted)
            }
            Switch(
                checked = accOn,
                onCheckedChange = {
                    askPerms()
                    ctx.startActivity(android.content.Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                },
                colors = SwitchDefaults.colors(
                    checkedTrackColor = Teal, checkedThumbColor = Color.White, checkedBorderColor = Color.Transparent,
                    uncheckedTrackColor = Color(0xFFD6D3D1), uncheckedThumbColor = Color.White, uncheckedBorderColor = Color.Transparent
                )
            )
        }
        Text(
            "قد يشترط نظام بلدك إبلاغ الطرف الآخر قبل التسجيل. تأكد من ذلك قبل التفعيل.",
            fontSize = 13.sp, color = Muted, modifier = Modifier.padding(top = 10.dp, start = 4.dp, end = 4.dp)
        )

        SectionLabel("النسخ الاحتياطي")
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Color.White)
                .border(1.dp, Line, RoundedCornerShape(20.dp)).padding(horizontal = 18.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("نسخة احتياطية (ZIP)", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Ink)
                Text("كل التسجيلات مع الاسم والرقم والتاريخ والمدة", fontSize = 13.sp, color = Muted)
            }
            Button(
                enabled = !busy,
                onClick = { saver.launch("CallRec_" + SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date()) + ".zip") },
                colors = ButtonDefaults.buttonColors(containerColor = Teal)
            ) { Text("إنشاء") }
        }
        if (msg.isNotEmpty()) Text(msg, fontSize = 13.sp, color = Muted, modifier = Modifier.padding(top = 10.dp, start = 4.dp))
    }
}
